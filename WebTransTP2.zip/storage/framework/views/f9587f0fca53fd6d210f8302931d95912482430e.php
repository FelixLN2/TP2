<?php echo e($slot); ?>

<?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>