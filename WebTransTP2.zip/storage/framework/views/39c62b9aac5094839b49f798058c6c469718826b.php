


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-md-12">
            <h1><?php echo e($animal->nom); ?></h1>
            <p class="lead"><?php echo e($animal->description); ?></p>
                 <!-- Display Uploaded Image -->
    <?php if(isset($animal) && $animal->image): ?>
        <div class="mt-3">
            <label for="animal-image">Image:</label>
            <img src="<?php echo e(asset('images/' . $animal->image)); ?>" alt="Animal Image" id="animal-image" class="img-thumbnail">
        </div>
    <?php endif; ?>
    <script>
    var animalImage = <?php echo json_encode($animal->image, 15, 512) ?>; // Assuming $animal->image is a string
    console.log("Animal Image:", animalImage);
</script>

            <div class="buttons">
                <a href="<?php echo e(url('animal/'. $animal->id .'/edit')); ?>" class="btn btn-info"><?php echo __('messages.modify'); ?></a>
                <form action="<?php echo e(url('animal/'. $animal->id)); ?>" method="POST" style="display: inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger"><?php echo __('messages.delete'); ?></button>
                </form>
            
            </div>
        </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/animal/show.blade.php ENDPATH**/ ?>