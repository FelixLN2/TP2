


<?php $__env->startSection('content'); ?>

<body>
<div class="container">
<div class="row">
<p> <B>Cette page va contenir des détails sur mon blog.</B></p>
<h2> Téléverser une image  </h2>
<form method = "POST" action = "<?php echo e(route('login')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type = "file" name= "photo">
    <input type = "submit" name= "Téléversser">

</form>



</div>
</div>
</body>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/televersement.blade.php ENDPATH**/ ?>