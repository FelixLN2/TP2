


<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="row">
        <div class="col-md-12">
            <h1><?php echo e($genus->nom); ?></h1>
            <p class="lead"><?php echo e($genus->description); ?></p>

            <div class="buttons">
                <a href="<?php echo e(url('genus/'. $genus->id .'/edit')); ?>" class="btn btn-info"><?php echo __('messages.modify'); ?></a>
                <form action="<?php echo e(url('genus/'. $genus->id)); ?>" method="POST" style="display: inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger"><?php echo __('messages.delete'); ?></button>
                </form>
            
            </div>

            <a href="<?php echo e(url('animal/create?genus_id=' . $genus->id)); ?>" class="btn btn-info"><?php echo __('messages.addanimal'); ?></a>
            <!-- Display Associated Animals -->
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2><?php echo __('messages.associatedanimals'); ?></h2>
            <?php if($genus->animal->count() > 0): ?>
                <ul>
                    <?php $__currentLoopData = $genus->animal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(url('animal/' . $animal->id)); ?>" class="btn btn-info"><?php echo e($animal->nom); ?></a> - <?php echo e($animal->description); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php else: ?>
                <p>No associated animals found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
        </div>
    </div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/genus/show.blade.php ENDPATH**/ ?>