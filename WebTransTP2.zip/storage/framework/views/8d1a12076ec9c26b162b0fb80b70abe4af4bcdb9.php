

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-lg-10">
            <h2>Mon blog avec Laravel</h2>
        </div>

        <div class="col-lg-2">
            <a class="btn btn-success" href="<?php echo e(url('genus/create')); ?>"><?php echo __('messages.addgenus'); ?></a>
        </div>

    </div>



    <?php if($message = Session::get('success')): ?>

        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>

    <?php endif; ?>



<div class="container">
    <div class="row">
        <?php $__currentLoopData = $genera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $genus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card card-body">
                <a href="<?php echo e(url('genus/'. $genus->id)); ?>">
                    <h2>
                        <?php echo e($genus->nom); ?>

                    </h2>
                </a>
            <p><?php echo __('messages.writtenby'); ?> <?php echo e($genus->user->name); ?> | date: <?php echo e($genus->created_at); ?></p>
            <a href="<?php echo e(url('genus/'. $genus->id)); ?>" class="btn btn-outline-primary"><?php echo __('messages.showdetails'); ?></a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/genus/index.blade.php ENDPATH**/ ?>