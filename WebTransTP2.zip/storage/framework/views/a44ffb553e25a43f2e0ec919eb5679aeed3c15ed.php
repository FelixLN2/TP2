


<?php $__env->startSection('content'); ?>


    <h1><?php echo __('messages.modifygenus'); ?> <?php echo e($genus->nom); ?></h1>


    <?php if($errors->any()): ?>

        <div class="alert alert-danger">

            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>

    <?php endif; ?>

    <form method="post" action="<?php echo e(url('genus/'. $genus->id . '/update')); ?>" >
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>


        <div class="form-group mb-3">

            <label for="nom"><?php echo __('messages.name'); ?></label>
            <input type="text" class="form-control" id="nom" placeholder="Entrer nom" name="nom" value="<?php echo e($genus->nom); ?>">

        </div>

        <div class="form-group mb-3">

            <label for="description"><?php echo __('messages.adddescription'); ?></label>
            <textarea name="description" id="description" cols="30" rows="10" class="form-control"><?php echo e($genus->description); ?></textarea>

        </div>

        <!--<div class="container">
            <div class="row">
           
            <p> <B>Cette page va contenir des détails sur mon blog.</B></p>
            <h2> Téléverser une image  </h2>
            <form method = "POST" action = "<?php echo e(route('login')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type = "file" name= "photo">
                <input type = "submit" name= "Téléversser">

            </form>
            </div>
        </div>-->
        <!--
        <div class="form-group mb-3">

            <label for="auteur">Auteur:</label>
            <input type="text" class="form-control" id="auteur" placeholder="Entrer auteur" name="auteur" value="<?php echo e($genus->auteur); ?>">

        </div>
        -->
 
        <button type="submit" class="btn btn-primary"><?php echo __('messages.save'); ?></button>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/genus/edit.blade.php ENDPATH**/ ?>