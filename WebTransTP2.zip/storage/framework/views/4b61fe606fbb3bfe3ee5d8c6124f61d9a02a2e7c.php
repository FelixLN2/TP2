<!-- resources/views/partials/language_switcher.blade.php -->

<?php $locale = session()->get('locale'); ?>
<li class="nav-item dropdown">
    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
        <?php switch($locale):
            case ('es'): ?>
                <img src="<?php echo e(asset('/images/flag/es.png')); ?>" width="30px" height="20px"> Español
                <?php break; ?>
            <?php case ('fr'): ?>
                <img src="<?php echo e(asset('/images/flag/fr.png')); ?>" width="30px" height="20px"> Français
                <?php break; ?>
            <?php default: ?>
                <img src="<?php echo e(asset('/images/flag/en.png')); ?>" width="30px" height="20px"> English
        <?php endswitch; ?>
        <span class="caret"></span>
    </a>

    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="<?php echo e(url('/lang/en')); ?>">
            <img src="<?php echo e(asset('/images/flag/en.png')); ?>" width="30px" height="20px"> English
        </a>
        <a class="dropdown-item" href="<?php echo e(url('/lang/fr')); ?>">
            <img src="<?php echo e(asset('/images/flag/fr.png')); ?>" width="30px" height="20px"> Français
        </a>
        <a class="dropdown-item" href="<?php echo e(url('/lang/es')); ?>">
            <img src="<?php echo e(asset('/images/flag/es.png')); ?>" width="30px" height="20px"> Español
        </a>
    </div>
</li>
<?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/partials/language_switcher.blade.php ENDPATH**/ ?>