


<?php $__env->startSection('content'); ?>


    <h1>Modifier animal: <?php echo e($animal->titre); ?></h1>


    <?php if($errors->any()): ?>

        <div class="alert alert-danger">

            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

        </div>

    <?php endif; ?>

    <form method="post" action="<?php echo e(url('animal/'. $animal->id  . '/update')); ?>"  enctype="multipart/form-data">
        <?php echo method_field('PATCH'); ?>
        <?php echo csrf_field(); ?>


          <div class="form-group mb-3">

            <label for="nom">nom:</label>
            <input type="text" class="form-control" id="nom" placeholder="Entrer nom" name="nom" value="<?php echo e($animal->nom); ?>">

        </div>

        <div class="form-group mb-3">

            <label for="description">Ajouter le contenu:</label>
            <textarea name="description" id="description" cols="30" rows="10" class="form-control" value="<?php echo e($animal->description); ?>"></textarea>

        </div>
        <div class="form-group mb-3">
            <label for="image">Téléverser une image:</label>
            <input type="file" name="image" class="form-control-file">
        </div>

       

  
        <button type="submit" class="btn btn-primary">Enregistrer</button>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/animal/edit.blade.php ENDPATH**/ ?>