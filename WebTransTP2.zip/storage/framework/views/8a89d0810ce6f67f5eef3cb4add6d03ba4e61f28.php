


<?php $__env->startSection('content'); ?>

<?php echo __('messages.test'); ?>


<body>
<div class="container">
<div class="row">
<ul>
    <img src="<?php echo e(asset('images/ConcepteurBD.png')); ?>" alt="Concepteur BD"  class="img-thumbnail"></li>
</ul>



</div>
</div>
</body>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\WebTransTP2\resources\views/apropos.blade.php ENDPATH**/ ?>