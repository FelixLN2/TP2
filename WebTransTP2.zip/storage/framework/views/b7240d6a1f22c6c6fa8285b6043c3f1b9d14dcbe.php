

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-lg-10">
            <h2>Mon blog avec Laravel</h2>
        </div>

        <div class="col-lg-2">
            <a class="btn btn-success" href="<?php echo e(url('genus/create')); ?>">Ajouter un genre</a>
        </div>

    </div>



    <?php if($message = Session::get('success')): ?>

        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>

    <?php endif; ?>



<div class="container">
    <div class="row">
        <?php $__currentLoopData = $genera; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $genus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card card-body">
                <a href="<?php echo e(url('genus/'. $genus->id)); ?>">
                <h2>
                        <?php echo e($genus->titre); ?>

                    </h2>
                </a>
            <p>Ecrit par: <?php echo e($genus->auteur); ?> | date: <?php echo e($genus->created_at); ?></p>
            <a href="<?php echo e(url('genus/'. $genus->id)); ?>" class="btn btn-outline-primary">En savoir plus</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\Ampps\www\TP2\resources\views/genus/index.blade.php ENDPATH**/ ?>