@extends('layouts.app')


@section('content')

{!! __('messages.test') !!}

<body>
<div class="container">
<div class="row">
<ul>
    <img src="{{ asset('images/ConcepteurBD.png') }}" alt="Concepteur BD"  class="img-thumbnail"></li>
</ul>



</div>
</div>
</body>

@endsection 