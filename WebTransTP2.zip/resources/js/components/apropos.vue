<template>
    <div>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="collapse navbar-collapse">
          <div class="navbar-nav">
              <ul>
                    <li>Félix Laprise-Narbonne</li>
                    <li>420-5H6MO Applications Web transactionnelles</li>
                    <li>Automne 2023, Collège Montmorency</li>
                    <br/>
                    <li>Application utilisant Vue en frontend et Laravel en backend</li>
                    <li>Les pages sont des fichiers .vue dans le dossier resources\js\ et resources\js\components</li>
                    <br/>
                    <li>Je peux ajouter, modifier et supprimer des genres</li>
                    <li>Je peux ajouter des animaux à ces genres et les modifier ou supprimer</li>
                    <li>Les animaux peuvent recevoir une image lors de la création ou ne pas en recevoir</li>

                    <li>Il y a une page de recherche</li>
                    <li>Dans la page, je peux entrer partiellement ou entièrement le nom d'un Genre <br/>et il apparaîtra en dessous de la barre de recherche et je pourrai cliquer dessus pour accéder à la page show.vue du Genre</li>
              </ul>
    
          </div>
        </div>
      </nav>
    </div>
  </template>
  
  <script>
  export default {};
  </script>