<?php
// EN folder
return [
    'Bonjour' => 'Hello',
    'apropos' => 'About',
    'login' => 'Login',
    'register' => 'Register',
    'logout' => 'Logout',
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'confirmpassword' => 'Conform password',
    'rememberme' => 'Remember me',
    'forgottenpassword' => 'Forgot your password?',
    'showdetails' => 'Show details',
    'writtenby' => 'Written by: ',
    'addgenus' => 'Add genus',
    'addanimal' => 'Add animal',
    'title' => 'Blog with Laravel',
    'associatedanimals' => 'Associated animals',
    'modifyanimal' => 'Modify Animal',
    'modifygenus' => 'Modify Genus',
    'modify' => 'Modify',
    'delete' => 'Delete',
    'addname' => 'name:',
    'adddescription' => 'Add content:',
    'save' => 'Save',
    'upload' => 'Upload a picture',
    'choosefile' => 'Choose a file',
    'nofilechosen' => 'No file chosen',
    'class' => '420-5H6 MO Transactional Web Applications',
    'college' => 'Autoumn 2023, Montmorency College',
    'uploadapropos' => 'You can upload a picture, works',
    'verifyapropos' => 'You receive an email to verify your email, works',
    'internationlizeapropos' => 'Localised',
    'back' => 'back',

    'IntroBlog' => 'Welcome !',
    'Site'=> 'League_of_legends',

    'test'=> "<ul>
    <li>Félix Laprise-Narbonne</li>
    <br/>
    <li>
        <ul>
            <li>420-5H6 MO Transactional Web Applications</li>
            <li>Fall 2023, Collège Montmorency</li>
        </ul>
    </li>
    <br/>
    <li>
        <ul>
            
            
            <li>tu peux uploader une image pour les animaux, fonctionne</li>
            <li>tu recois un mail de verification quand tu register, fonctionne</li>
            <li>internationalistion marche pas, suivi le lien </li>
        </ul>
    </li>
  
</ul>",
];