<?php
// FR folder
return [
    'Bonjour' => 'Hello',
    'apropos' => 'À propos',
    'login' => 'Se Connecter',
    'register' => 'Enregistrer',
    'logout' => 'Déconnexion',
    'name' => 'Nom',
    'email' => 'Courriel',
    'password' => 'Mot de passe',
    'confirmpassword' => 'Confirmation mot de passe',
    'rememberme' => 'Mémoriser',
    'forgottenpassword' => 'Oublié mot de passe?',
    'showdetails' => 'En savoir plus',
    'writtenby' => 'Ecrit par: ',
    'addgenus' => 'Ajouter un genre',
    'addanimal' => 'Ajouter un animal',
    'modifyanimal' => 'Modifier Animal',
    'modifygenus' => 'Modifier Genre',
    'title' => 'Mon blog avec  Laravel',
    'associatedanimals' => 'Animaux associés',
    'modify' => 'Modifier',
    'delete' => 'Supprimer',
    'addname' => 'nom:',
    'adddescription' => 'Ajouter le contenu:',
    'save' => 'Enregistrer',
    'upload' => 'Téléverser une image',
    'choosefile' => 'Choisir un fichier',
    'nofilechosen' => 'Aucun fichier choisi',
    'class' => '420-5H6 MO Applications Web transactionnelles',
    'college' => 'Automne 2023, Collège Montmorency',
    'uploadapropos' => 'tu peux uploader une image pour les animaux, fonctionne',
    'verifyapropos' => 'tu recois un mail de verification quand tu register, fonctionne',
    'internationlizeapropos' => 'cest internationalisé',
    'back' => 'retour',

    'test'=> "<ul>
    <li>Félix Laprise-Narbonne</li>
    <br/>
    <li>
        <ul>
            <li>420-5H6MO Applications Web transactionnelles</li>
            <li>Automne 2023, Collège Montmorency</li>
        </ul>
    </li>
    <br/>
    <li>
        <ul>
            
            
            <li>tu peux uploader une image pour les animaux, fonctionne</li>
            <li>tu recois un mail de verification quand tu register, fonctionne</li>
            <li>internationalisation en francais, anglais et espagnol, fonctionn</li>
        </ul>
    </li>",




];